# -*- coding: utf-8 -*-
from odoo import http

# class Dzhotel(http.Controller):
#     @http.route('/dzhotel/dzhotel/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/dzhotel/dzhotel/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('dzhotel.listing', {
#             'root': '/dzhotel/dzhotel',
#             'objects': http.request.env['dzhotel.dzhotel'].search([]),
#         })

#     @http.route('/dzhotel/dzhotel/objects/<model("dzhotel.dzhotel"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('dzhotel.object', {
#             'object': obj
#         })