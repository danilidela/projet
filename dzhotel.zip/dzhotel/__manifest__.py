# -*- coding: utf-8 -*-
{
    'name': "dzhotel",

    'summary': """
        Module pour la gestion hôtel """,

    'description': """
        Long description of module's purpose
    """,

    'author': "My Company",
    'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/12.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'mail', 'contacts'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'data/email_template_view.xml',
        'views/views.xml',
        'reports/factureresvchamb.xml',
        'reports/chmabresvfacture.xml',
        'reports/factureresvsalle.xml',
        'reports/salleresvfacture.xml',
        'reports/facturecommande.xml',
        'reports/commandefacture.xml',
        'reports/reportreservations.xml',
        'reports/reservationsreporte.xml',
        'reports/reportsalle.xml',
        'reports/sallereport.xml',
        'reports/reporttable.xml',
        'reports/tablereport.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'installable': True,
	'application': True,
	'auto_install': False,
}