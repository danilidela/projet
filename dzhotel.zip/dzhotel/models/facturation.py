# -*- coding: utf-8 -*-
import time
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT as dt
from odoo.exceptions import ValidationError, UserError
import pytz
class HotelFacturationChambre(models.Model):
    _name='hotel.facturation.chambre'
    _description='facturation'


    facturation_num = fields.Char('Facturation:', readonly=True, required=True, copy=False, default=lambda self: _('New'))
    @api.model
    def create(self, vals):
            if vals.get('facturation_num', 'New') == 'New':
                vals['facturation_num'] = self.env['ir.sequence'].next_by_code('hotel.facturation.chambre') or 'New'
                result = super(HotelFacturationChambre, self).create(vals)
                return result
    
   
    reservationnum = fields.Char('Réservation:')
    debut_resvv = fields.Datetime(string="Date d'arrivée")
    fin_resvv= fields.Datetime(string="Date de départ")
    adultess = fields.Integer(string="adultes")
    enfantss = fields.Integer(string="Enfants")
    clients_idd = fields.Many2one("hotel.clients", string="Client")
    date_commdd = fields.Datetime('Date', readonly=True, required=True, index=True, default=(lambda *a: time.strftime(dt)))
    # -*-chambre_idss = fields.One2many(comodel_name='hotel.chambres',required=True, inverse_name='reservation_id')  
    chambre_idss = fields.One2many('reservation.chambre.ligne','chambreligneid')
    tarifss = fields.Float('Tarif')

   
class HotelFacturationSalle(models.Model):
    _name='hotel.facturation.salle'
    _description='facturation'


    facturation_num = fields.Char('Facturation:', readonly=True, required=True, copy=False, default=lambda self: _('New'))
    @api.model
    def create(self, vals):
            if vals.get('facturation_num', 'New') == 'New':
                vals['facturation_num'] = self.env['ir.sequence'].next_by_code('hotel.facturation.salle') or 'New'
                result = super(HotelFacturationSalle, self).create(vals)
                return result    

    date_commdd = fields.Datetime('Date', readonly=True, required=True, index=True, default=(lambda *a: time.strftime(dt)))
    reservation_num_v = fields.Char('Réservation:')
    nom_client_s = fields.Many2one('hotel.clients', string='Nom de client',)
    heure_de_debut_s = fields.Datetime('Heure de début', required=True ,)
    heure_de_fin_s = fields.Datetime('Heure de fin', required=True)
    salle_idss = fields.One2many('reservation.salle.ligne', 'salleligneid')
    tarifss = fields.Float('Tarif')

class HotelFacturationCommande(models.Model):
    _name='hotel.facturation.commande'
    _description='facturation'


    facturation_num = fields.Char('Facturation:', readonly=True, required=True, copy=False, default=lambda self: _('New'))
    @api.model
    def create(self, vals):
            if vals.get('facturation_num', 'New') == 'New':
                vals['facturation_num'] = self.env['ir.sequence'].next_by_code('hotel.facturation.commande') or 'New'
                result = super(HotelFacturationCommande, self).create(vals)
                return result    

    
    commandeum = fields.Char('Commande:')
    table_resv_c = fields.Many2one('hotel.restaurant.reservations', 'Reservation Table')
    order_date_c = fields.Datetime('Date', required=True, default=(lambda *a: time.strftime (dt)))
    nom_du_serveur_c = fields.Many2one('hotel.clients', 'Nom du serveur')
    commande_idss = fields.One2many('reservation.commande.ligne', 'commandeligneid')
    tarifss = fields.Float('Tarif')