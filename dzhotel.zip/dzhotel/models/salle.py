# -*- coding: utf-8 -*-
import time
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT as dt
from odoo.exceptions import ValidationError, UserError
import pytz

class HotelSalleReservations(models.Model):

    @api.onchange('salleligne_id')
    def sommetotal(self):
        for order in self:
            amount_total = 0.0

        for line in order.salleligne_id:
            amount_total += line.tarif_salle
            order.tarifs = amount_total


    
    @api.multi
    def salle_reserved(self):
        self.state = 'confirm'
        return True
    
    @api.multi
    def creefacturesalle(self):
        self.state = 'done'
        for order in self:
            rooms_ids = []
            for line in order.salleligne_id:
                rooms_ids.append(
                    (15, 15,
                     {

                'nom' : line.nom,
                'type_salle' : line.type_salle,
                'nomb_perso' : line.nomb_perso,
                'description' : line.description,
                'tarif_salle' : line.tarif_salle,

                     }
                     ))
                vals = {
            'reservation_num_v': self.reservation_num,
            'date_commdd': self.date_commd,
            'nom_client_s': self.nom_client.id,
            'heure_de_debut_s': self.heure_de_debut,
            'heure_de_fin_s': self.heure_de_fin,
            'tarifss': self.tarifs,
            'salle_idss': rooms_ids

                }
        
        self.env['hotel.facturation.salle'].create(vals)

    @api.multi
    def sallefacteurcration(self):
        self.state = 'done'
        for order in self:
            rooms_ids = []
            for line in order.salleligne_id:
                rooms_ids.append(
                    (15, 15,
                     {

                'nom' : line.nom,
                'type_salle' : line.type_salle,
                'nomb_perso' : line.nomb_perso,
                'description' : line.description,
                'tarif_salle' : line.tarif_salle,

                     }
                     ))
                vals = {
            'reservation_num_v': self.reservation_num,
            'date_commdd': self.date_commd,
            'nom_client_s': self.nom_client.id,
            'heure_de_debut_s': self.heure_de_debut,
            'heure_de_fin_s': self.heure_de_fin,
            'tarifss': self.tarifs,
            'salle_idss': rooms_ids

                }
        
        self.env['hotel.facturation.salle'].create(vals)

        
    @api.multi
    def myfacturesalle(self):
            return {
                'name': _('Facture'),
                'view_type': 'form',
                'res_model': 'hotel.facturation.salle',
                'view_id': False,
                'view_mode': 'tree,form',
                'type': 'ir.actions.act_window'
            }
       
    
    @api.multi
    def salle_cancel(self):
        self.state = 'cancel'
        return True

    @api.multi
    def action_send_reservation_mail(self):
        ir_model_data = self.env['ir.model.data']
        try:
            template_id = ir_model_data.get_object_reference('dzhotel', 'email_template_hotel_reservations')
            self.env['mail.template'].browse(template_id).send_mail(self.id, force_send=True)
        except ValueError:
            template_id = False
        
        ctx = {
            'default_model': 'hotel.salle.reservations',
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'email_to':self.nom_client.email,
            'mark_so_as_sent': True,
            'force_email': True
        }
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'target': 'new',
            'context': ctx,
        }

    
    
    
    
    
    _name = "hotel.salle.reservations"
    _description = "Comprend la réservation de salel de l'hôtel"

    # -*- le num de reservation  -*-
    reservation_num = fields.Char('Réservation:', readonly=True, required=True, copy=False, default=lambda self: _('New'))
    
    @api.model
    def create(self, vals):
            if vals.get('reservation_num', 'New') == 'New':
                vals['reservation_num'] = self.env['ir.sequence'].next_by_code('hotel.salle.reservations') or 'New'
                result = super(HotelSalleReservations, self).create(vals)
                return result

    # -*- La date actuelle -*- 
    date_commd = fields.Datetime('Date', readonly=True, required=True, index=True, default=(lambda *a: time.strftime(dt)))
    nom_client = fields.Many2one('hotel.clients', string='client', required=True, readonly=True, states={'draft': [('readonly', False)]})
    heure_de_debut = fields.Datetime('Heure de début', required=True ,)
    heure_de_fin = fields.Datetime('Heure de fin', required=True)

    @api.constrains('heure_de_debut', 'heure_de_fin')
    def heure_de_debut_heure_de_fin(self):
        if self.heure_de_fin and self.heure_de_debut:
            if self.heure_de_debut < self.date_commd:
                raise ValidationError(_('La Heur debut doit être supérieure à \
                                        la date actuelle.'))
            if self.heure_de_fin < self.heure_de_debut:
                raise ValidationError(_('La date fin doit être supérieure \
                                         que la date debut.'))



    salleligne_id = fields.One2many('reservation.salle.ligne','salleligneid')# -*-,required=True, string='Numéro de salle'
    state = fields.Selection([('draft', 'Brouillon'), ('confirm', 'Confirmé'), ('done', 'Valider'), ('cancel', 'Annuler'), ('order', 'Commande créée')], 'state', index=True, required=True, readonly=True, default=lambda * a: 'draft')

    @api.multi
    def action_set_to_draft(self):
        self.state = 'draft'
        return True
    
    # -*- Espace Tarif  -*-
    tarifs = fields.Float('Tarif', compute='sommetotal')


class HotelSalle(models.Model):
    _name = "hotel.salles"
    _description = "salles"

    nom = fields.Char('Salle', required=True, index=True)
    MODE=[('1','Salle des fête'),('2','Salle de réunion'),('3','Salle des conférences')]
    type_salle =fields.Selection(MODE)
    nomb_perso =  fields.Integer('Nombre des Personnes')
    tarif_salle = fields.Float('Tarif')
    description=fields.Text(string="Description")


class ReservationSalleLigne(models.Model):
    _name = "reservation.salle.ligne"
    _description = "salle ligne"

    salleligneid = fields.Many2one(comodel_name='hotel.salle.reservations')
    salle_ids = fields.Many2one(comodel_name='hotel.salles')
    nom = fields.Char(related='salle_ids.nom')
    type_salle =fields.Selection(related='salle_ids.type_salle')
    nomb_perso =  fields.Integer(related='salle_ids.nomb_perso')
    description=fields.Text(related='salle_ids.description')
    tarif_salle = fields.Float('Tarif',related='salle_ids.tarif_salle')
