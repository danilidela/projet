# -*- coding: utf-8 -*-
import time
from datetime import datetime as dtt, timedelta 
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT as dt
from odoo.exceptions import ValidationError, UserError
import pytz

# -*- ==============================  Reservation ============================== -*- 
class HotelReservation(models.Model):
    _name = "hotel.reservations"
    _description = "Reservation"
    
   
    photo = fields.Binary(string='Image')
    # -*- le num de reservation  -*-
    reservation_num = fields.Char('Réservation:', readonly=True, required=True, copy=False, default=lambda self: _('New'))
    
    @api.model
    def create(self, vals):
            if vals.get('reservation_num', 'New') == 'New':
                vals['reservation_num'] = self.env['ir.sequence'].next_by_code('hotel.reservations') or 'New'
                result = super(HotelReservation, self).create(vals)
                return result
    
   
    
    # -*- La date actuelle -*- 
    date_commd = fields.Datetime('Date', readonly=True, required=True, index=True, default=(lambda *a: time.strftime(dt)))
    # -*- Les date de reservation -*- 
    debut_resv= fields.Datetime(string="Date d'arrivée", required=True, readonly=True, states={'draft': [('readonly', False)]})
    fin_resv= fields.Datetime(string="Date de départ", required=True, readonly=True, states={'draft': [('readonly', False)]})
    @api.constrains('debut_resv', 'fin_resv')
    def debut_resv_fin_resv(self):
        if self.fin_resv and self.debut_resv:
            if self.debut_resv < self.date_commd:
                raise ValidationError(_('La date d arrivée doit être supérieure à \
                                        la date actuelle.'))
            if self.fin_resv < self.debut_resv:
                raise ValidationError(_('La date de départ doit être supérieure \
                                         que la date d arrivée.'))

    # -*- Le nombre ne personne -*- 
    adultes= fields.Integer(string="adultes", required=True, readonly=True, states={'draft': [('readonly', False)]})
    enfants= fields.Integer(string="Enfants", readonly=True, states={'draft': [('readonly', False)]})
    @api.constrains('adultes', 'enfants')
    def check_reservation_rooms(self):
        ctx = dict(self._context) or {}
        for reservation in self:
            if not ctx.get('duplicate'):    
                if reservation.adultes <= 0:
                    raise ValidationError(_('Les adultes doivent être plus de 0'))
    # -*- La création d'un hotel  -*-
    entrepot_id = fields.Char( string="Hotel Blida", readonly=True,)
    # -*- La création d'un client  -*-
    clients_id = fields.Many2one("hotel.clients", string="Client", required=True, readonly=True, states={'draft': [('readonly', False)]})
    # -*- Espace Chambre  -*-
    # -*-ligne_de_reservation=fields.One2many('reservation.chambre.ligne', 'chambreligneid', 'Chambre', required=True, readonly=True, states={'draft': [('readonly', False)]})
    ligne_de_reservation=fields.One2many('reservation.chambre.ligne', 'chambreligneid')
    
    # -*- Espace Tarif  -*-
    tarifs = fields.Float('Tarif', compute='sommetotal')

    @api.onchange('ligne_de_reservation','debut_resv','fin_resv')
    def sommetotal(self):
     for order in self:
         amount_total = 0.0
         daysDiff = 0.0
     if order.debut_resv and order.fin_resv:
        fmt = '%Y-%m-%d'
        debut = order.debut_resv
        fin = order.fin_resv
        d1 = dtt.strftime(debut, fmt)
        d2 = dtt.strftime(fin, fmt)
        d3 = dtt.strptime(d1, fmt)
        d4 = dtt.strptime(d2, fmt)
        daysDiff = float((d4 - d3).days)

     for line in order.ligne_de_reservation:
        amount_total += line.tarfi_chambre
        order.tarifs = amount_total * daysDiff
            

    # -*-commodite = fields.Many2one("hotel.commodite", string="Commodite", readonly=True, states={'draft': [('readonly', False)]})
    # -*- Header  -*-
    state = fields.Selection([('draft', 'Brouillon'), ('confirm', 'Confirmer'), ('cancel', 'Annuler'), ('done', 'Valider')],'State', index=True, required=True, readonly=True, default=lambda *a: 'draft')
    # -*- button  -*-
    # -*- confirmed reservation -*-# -*- confirmed reservation -*-# -*- confirmed reservation -*-# -*- confirmed reservation -*-
    @api.multi
    def confirmed_reservation(self):
        self.state = 'confirm'
        return True
    # -*- Envoyer un e-mail de réservation -*- # -*- Envoyer un e-mail de réservation -*- # -*- Envoyer un e-mail de réservation -*-
    @api.multi
    def action_send_reservation_mail(self):
        self.ensure_one()
        ir_model_data = self.env['ir.model.data']
        try:
            template_id = ir_model_data.get_object_reference('dzhotel', 'email_template_hotel_reservations')
            self.env['mail.template'].browse(template_id).send_mail(self.id, force_send=True)
        except ValueError:
            template_id = False
        
        ctx = {
            'default_model': 'hotel.reservations',
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'email_to':self.clients_id.email,
            'mark_so_as_sent': True,
            'force_email': True
        }
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'target': 'new',
            'context': ctx,
        }
    # -*- Annuler une réservation -*-## -*- Annuler une réservation -*-## -*- Annuler une réservation -*-## -*- Annuler une réservation -*-#
    @api.multi
    def cancel_reservation(self):
        self.state = 'cancel'
        return True
    # -*- Set to Draft -*-## -*- Set to Draft -*-## -*- Set to Draft -*-## -*- Set to Draft -*-## -*- Set to Draft -*-#
    @api.multi
    def set_to_draft_reservation(self):
        self.state = 'draft'
        return True
    # -*- Ctrée une facture -*-#
    # -*-@api.multi
    # -*-def action_valider(self):
        # -*-self.state = 'done'
        # -*-return True

    @api.multi
    def creefacture(self):
        self.state = 'done'
        for order in self:
            rooms_ids = []
            for line in order.ligne_de_reservation:
                rooms_ids.append(
                    (30, 30,
                    {
                    'nom': line.nom,
                    'capacity': line.capacity,
                    'tarfi_chambre': line.tarfi_chambre,
                    }
                    ))
        vals ={
            'chambre_idss': rooms_ids,
            'debut_resvv': self.debut_resv,
            'fin_resvv': self.fin_resv,
            'adultess': self.adultes,
            'enfantss': self.enfants,
            'tarifss': self.tarifs,
            'clients_idd': self.clients_id.id,
            'date_commdd': self.date_commd,
            'reservationnum': self.reservation_num,
            }
            
        self.env['hotel.facturation.chambre'].create(vals)

    @api.multi
    def ChambreFacteurCreation(self):
        self.state = 'done'
        for order in self:
            rooms_ids = []
            for line in order.ligne_de_reservation:
                rooms_ids.append(
                    (15, 15,
                    {
                    'nom': line.nom,
                    'etage_id':line.etage_id,
                    'capacity': line.capacity,
                    'tarfi_chambre': line.tarfi_chambre,
                    }
                    ))
        vals ={
            'chambre_idss': rooms_ids,
            'debut_resvv': self.debut_resv,
            'fin_resvv': self.fin_resv,
            'adultess': self.adultes,
            'enfantss': self.enfants,
            'tarifss': self.tarifs,
            'clients_idd': self.clients_id.id,
            'date_commdd': self.date_commd,
            'reservationnum': self.reservation_num,
            }
            
        self.env['hotel.facturation.chambre'].create(vals)
        
    @api.multi
    def MyFactureChambre(self):
        return {
                'name': _('Facture'),
                'view_type': 'form',
                'res_model': 'hotel.facturation.chambre',
                'view_id': False,
                'view_mode': 'tree,form',
                'type': 'ir.actions.act_window'
            }

    
    @api.multi
    def myfacture(self):
            return {
                'name': _('Facture'),
                'view_type': 'form',
                'res_model': 'hotel.facturation.chambre',
                'view_id': False,
                'view_mode': 'tree,form',
                'type': 'ir.actions.act_window'
            }


        
# -*- ==============================  Client Particulier  ============================== -*- 
class HotelClient(models.Model):
    _name = 'hotel.clients'
    _description = "Clients"
    _rec_name='nom'

    # -*- les deux Smart Button Actif et retours -*-
    active=fields.Boolean(string="Archive", default=True)
    # -*- Image -*-
    image_medium=fields.Binary(attachment=True)
     # -*- radio button -*-
    # -*-type_radio=fields.Selection(string="type", default='particulier', selection=[('particulier', 'Particulier'),('societe', 'Société')] , compute='_compute_company_type', readonly=False)
    # -*-is_company = fields.Boolean(string='Is a Company', default=False, help="Check if the contact is a company, otherwise it is a person")
    
    # -*-@api.depends('is_company')
    # -*-def _compute_company_type(self):
        # -*-for partner in self:
            # -*-partner.type_radio = 'societe'  if partner.is_company else 'particulier'
            
    # -*-@api.onchange('type_radio')
    # -*-def onchange_company_type(self):
        # -*-self.is_company = (self.type_radio == 'societe')
            
    # -*-societe_fields=fields.Many2one('hotel.societes', 'Societe')

    # -*- les Information de Client -*-
    nom=fields.Char(string="Nom", required=True)
    prenom=fields.Char(string="Prenom", required=True)
    Titre=fields.Many2one('res.partner.title', string="Civilité")
    post_occupe=fields.Char(string="Post Occupé")

    date_de_naiss=fields.Date(string="Date de naissance")
    lieu_de_naiss=fields.Char(string="Lieu de naissance")
    Pays_de_naiss=fields.Many2one('res.country', string="Pays de naissance")

    telep=fields.Integer(string="Telephone")
    fax=fields.Integer(string="Fax")
    email=fields.Char(string="E-Mail")
    
    rue1=fields.Char()
    rue2=fields.Char()
    ville=fields.Char()
    etat=fields.Many2one('res.country.state')
    code_post=fields.Char()
    country_id=fields.Many2one('res.country')

    type_idd=fields.Selection([('I1', "Cartes d'identité"), ('I2', 'Passporte'), ('I3', 'carte de séjour'), ('I4', 'permi de conduite')], string='Type identification')
    num_idd=fields.Char(string='Numéro identité')

    site_web=fields.Char(string="Site Web")

    note_inter=fields.Text(string="Notes Internes")
    

    

# -*- ==============================  Client Societe  ============================== -*- 
# -*-class HotelSocietes(models.Model):
    # -*-_name = "hotel.societes"
    # -*-_description = "Societe"

    # -*- les deux Smart Button Actif et retours -*-
    # -*-active=fields.Boolean(string="Archive", default=True)

    # -*- Image -*-
    # -*-image_medium=fields.Binary(attachment=True)
    
    # -*-type_radio=fields.Selection(string="type",default='societe', selection=[('particulier', 'Particulier'),('societe', 'Société')] , compute='_compute_company_type', readonly=False)
    # -*-is_company = fields.Boolean(string='Is a Company', default=False, help="Check if the contact is a company, otherwise it is a person")
    
    # -*-@api.depends('is_company')
    # -*-def _compute_company_type(self):
        # -*-for partner in self:
            # -*-partner.type_radio = 'societe'  if partner.is_company else 'particulier'
            
    # -*-@api.onchange('type_radio')
    # -*-def onchange_company_type(self):
        # -*-self.is_company = (self.type_radio == 'societe')

    # -*-societe_fields=fields.Many2one('hotel.societes', 'Societe', required=True,)

    # -*- les Information de Societe -*-
    # -*-nom=fields.Char(string="Nom", required=True)
    # -*-prenom=fields.Char(string="Prenom", required=True)
    # -*-Titre=fields.Many2one('res.partner.title', string="Civilité")
    # -*-post_occupe=fields.Char(string="Post Occupé")

    # -*-date_de_naiss=fields.Date(string="Date de naissance")
    # -*-lieu_de_naiss=fields.Char(string="Lieu de naissance")
    # -*-Pays_de_naiss=fields.Many2one('res.country', string="Pays de naissance")

    # -*-telep=fields.Integer(string="Telephone")
    # -*-fax=fields.Integer(string="Fax")
    # -*-email=fields.Char(string="Email")
    # -*-site_web=fields.Char(string="Site Web")
    
    # -*-rue1=fields.Char()
    # -*-rue2=fields.Char()
    # -*-ville=fields.Char()
    # -*-etat=fields.Many2one('res.country.state')
    # -*-code_post=fields.Char()
    # -*-country_id=fields.Many2one('res.country')

    # -*-type_idd=fields.Selection([('I1', "Cartes d'identité"), ('I2', 'Passporte'), ('I3', 'carte de séjour'), ('I4', 'permi de conduite')], string='Type identification')
    # -*-num_idd=fields.Char(string='Numéro identité')
    # -*-note_inter=fields.Text(string="Notes Internes")
    
    # -*- ==============================  Réservation Chambre ligne  ============================== -*- 
class ReservationChambreLigne(models.Model):
    _name = "reservation.chambre.ligne"
    _description = "Chambre ligne"
    chambreligneid = fields.Many2one(comodel_name='hotel.reservations')
    chambre_ids = fields.Many2one(comodel_name='hotel.chambres')
    capacity = fields.Integer(string="capacité",related='chambre_ids.capacity', default='2')
    tarfi_chambre = fields.Float(string="Tarif de la Chambre",related='chambre_ids.tarfi_chambre')
    nom=fields.Char(string="nom",related='chambre_ids.nom',required=True)
    etage_id = fields.Char('etage',related='chambre_ids.etage_id', required=True, index=True)
    statut = fields.Selection(related='chambre_ids.statut')
    categ_id = fields.Selection(related='chambre_ids.categ_id')
    chembre_net = fields.Boolean(related='chambre_ids.chembre_net')
    dernier_nettoyage = fields.Datetime(related='chambre_ids.dernier_nettoyage')
    salle_de_bain = fields.Boolean(related='chambre_ids.salle_de_bain')
    toilette = fields.Boolean(related='chambre_ids.toilette')
    televiseur = fields.Boolean(related='chambre_ids.televiseur')
    Douche_privee = fields.Boolean(related='chambre_ids.Douche_privee')
    telephone = fields.Boolean(related='chambre_ids.telephone')
    num_tel = fields.Integer(related='chambre_ids.num_tel')
    climatiseur = fields.Boolean(related='chambre_ids.climatiseur')




    










































































































































































