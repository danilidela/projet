# -*- coding: utf-8 -*-
import time
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT as dt
from odoo.exceptions import ValidationError, UserError
import pytz

# -*- interface réservation table
class HotelRestaurantReservations(models.Model):
    _name = "hotel.restaurant.reservations"
    _description = "Comprend la réservation du restaurant de l'hôtel"
    

    nom_client = fields.Many2one("hotel.clients", string='client')
    heure_de_debut = fields.Datetime('Heure de début', required=True)
    heure_de_fin = fields.Datetime('Heure de fin', required=True)
    # -*-table = fields.Many2many('hotel.restaurant.tabless', index=True, string='table', help="Détail de réservation de table. ")
    table = fields.One2many('reservation.table.ligne','tableligneid')
    
    state = fields.Selection([('draft', 'Brouillon'), ('confirm', 'Confirmé'), ('done', 'Valider'), ('cancel', 'Annuler'), ('order', 'Commande créée')], 'state', index=True, required=True, readonly=True, default=lambda * a: 'draft')
    # -*- le num de reservation  -*-
    reservation_num = fields.Char('Réservation:', readonly=True, required=True, copy=False, default=lambda self: _('New'))
    
    @api.model
    def create(self, vals):
            if vals.get('reservation_num', 'New') == 'New':
                vals['reservation_num'] = self.env['ir.sequence'].next_by_code('hotel.restaurant.reservations') or 'New'
                result = super(HotelRestaurantReservations, self).create(vals)
                return result
    
    @api.multi
    def table_reserved(self):
        self.state = 'confirm'
        return True

    @api.multi
    def table_cancel(self):
        self.state = 'cancel'
        return True
    
    @api.multi
    def action_send_reservation_mail(self):
        self.ensure_one()
        ir_model_data = self.env['ir.model.data']
        try:
            template_id = ir_model_data.get_object_reference('dzhotel', 'email_template_hotel_reservations')
            self.env['mail.template'].browse(template_id).send_mail(self.id, force_send=True)
        except ValueError:
            template_id = False
        
        ctx = {
            'default_model': 'hotel.restaurant.reservations',
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'email_to':self.nom_client.email,
            'mark_so_as_sent': True,
            'force_email': True
        }
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'target': 'new',
            'context': ctx,
        }
    
    @api.multi
    def action_set_to_draft(self):
        self.state = 'draft'
        return True

# -*- interface table
class HotelRestaurantTables(models.Model):
        
    _name = "hotel.restaurant.tabless"
    _description = "Comprend la table du restaurant de l'hôtel"

    num = fields.Char('table', required=True, index=True)
    capacite = fields.Integer('capacité')


class ReservationTableLigne(models.Model):
    _name = "reservation.table.ligne"
    _description = "table ligne"

    tableligneid = fields.Many2one(comodel_name='hotel.restaurant.reservations')
    table_table = fields.Many2one('hotel.restaurant.tabless', 'table')
    num = fields.Char('table', related='table_table.num')
    capacite = fields.Integer('capacité', related='table_table.capacite')

class HotelRestaurantOrders(models.Model):

    @api.onchange('order_list')
    def sommetotal(self):
        for order in self:
            amount_total = 0.0

        for line in order.order_list:
            amount_total += line.tarif_repas
            order.tarifs = amount_total

    @api.multi
    def commande_reserved(self):
        self.state = 'confirm'
        return True
    
    @api.multi
    def creefacturecommande(self):
        self.state = 'done'
        for order in self:
            commande_ids = []
            for line in order.order_list:
                commande_ids.append(
                    (15, 15,
                     {

                         'nom': line.nom,
                         'tarif_repas': line.tarif_repas,
                         

                     }
                     ))
       
        vals ={
            'order_date_c': self.order_date,
            'nom_du_serveur_c': self.nom_du_serveur.id,
            'table_resv_c': self.table_resv.id,
            'tarifss': self.tarifs,
            'commandeum': self.commande_num,
            'commande_idss' : commande_ids
            }
        
        self.env['hotel.facturation.commande'].create(vals)
        
    @api.multi
    def myfacturecommande(self):
            return {
                'name': _('Facture'),
                'view_type': 'form',
                'res_model': 'hotel.facturation.commande',
                'view_id': False,
                'view_mode': 'tree,form',
                'type': 'ir.actions.act_window'
            }
      
    
    @api.multi
    def commande_cancel(self):
        self.state = 'cancel'
        return True

    @api.multi
    def action_set_to_draft(self):
        self.state = 'draft'
        return True
    
    
    _name = "hotel.restaurant.orders"
    _description = "Reservation Order"


    commande_num = fields.Char('Commande:', readonly=True, required=True, copy=False, default=lambda self: _('New'))
    @api.model
    def create(self, vals):
            if vals.get('commande_num', 'New') == 'New':
                vals['commande_num'] = self.env['ir.sequence'].next_by_code('hotel.restaurant.orders') or 'New'
                result = super(HotelRestaurantOrders, self).create(vals)
                return result
    

    table_resv = fields.Many2one('hotel.restaurant.reservations', 'Reservation Table')
    order_date = fields.Datetime('Date', required=True, default=(lambda *a: time.strftime (dt)))
    nom_du_serveur = fields.Many2one('hotel.clients', string='serveur',)
    order_list = fields.One2many('reservation.commande.ligne','commandeligneid')

    state = fields.Selection([('draft', 'Brouillon'), ('confirm', 'Confirmé'), ('done', 'Valider'), ('cancel', 'Annuler'), ('order', 'Commande créée')], 'state', index=True, required=True, readonly=True, default=lambda * a: 'draft')


# -*- Espace Tarif  -*-
    tarifs = fields.Float('Tarif', compute='sommetotal')

class ReservationCommandeLigne(models.Model):
    _name = "reservation.commande.ligne"
    _description = "commande ligne"
   
    # -*-menu = fields.Many2many('hotel.carte_menu', 'Menu', required=True)
    menu = fields.Many2one('hotel.carte_menu', 'Menu')
    qty = fields.Integer(string='Quantité', required=True, default=1)
    nom = fields.Char('Nom',related='menu.nom')

    tarif_repas = fields.Float('Tarif', related='menu.tarif_repas')
    commandeligneid = fields.Many2one(comodel_name='hotel.restaurant.orders')

    @api.onchange('qty')
    def calculeprixqty(self):
        amount = self.tarif_repas
        qty = self.qty
        for order in self:
            order.tarif_repas = amount * qty







class HotelCarteMenu(models.Model):
    _name = 'hotel.carte_menu'
    _description = 'Hotel Menu Carte'
    _rec_name = 'nom'

    nom = fields.Char('Nom', required=True)
    image_medium = fields.Binary("Image")
    statut = fields.Selection([('oui', 'Oui'),('no', 'No')],'Statut',default='no')
    isrepas=fields.Boolean('Is Repas')
    tarif_repas = fields.Float('Tarif')

    @api.onchange('isrepas')
    def isrepas_change(self):
        if self.isrepas is False:
            self.statut = 'no'
        
        if self.isrepas is True:
            self.statut = 'oui'

    
    

    

    

    

