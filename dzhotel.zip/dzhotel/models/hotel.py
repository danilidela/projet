# -*- coding: utf-8 -*-
import time
from datetime import datetime as dtt, timedelta
from odoo import models, fields, api
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT as dt






class HotelChambre(models.Model):
    _name='hotel.chambres'
    _description='Chambre'

     # -*- Image -*-
    image_medium=fields.Binary(attachment=True)
     # -*- Les information de la chambre -*-
    nom=fields.Char(string="Numéro de la chambre",required=True)
    # -*-statut = fields.Selection([('disponible', 'Disponible'),('occupee', 'occupée')],'Statut', default="disponible")
    statut = fields.Selection(selection='_populate_choice', string='Statut', default='disponible')
    # -*-isroom = fields.Boolean('Is Room')

    @api.model
    def _populate_choice(self):
        choices=[('disponible', 'Disponible'),('occupee', 'Occupée')]
        return choices

    # -*-@api.onchange('isroom')
    # -*-def isroom_change(self):
        # -*-for partner in self:
            # -*-partner.statut = 'occupee' if partner.isroom else 'disponible' 

    # -*-@api.onchange('isroom')
    # -*-def isroom_change(self):
    
        # -*-if self.isroom is False:
            # -*-self.statut = 'disponible'
              
        # -*-if self.isroom is True:
            # -*-self.statut = 'occupee'
    
    
    
    
    etage_id = fields.Char('etage', required=True, index=True)
    MODE=[('seule','CHAMBRE SEULE'),('double','CHAMBRE DOUBLE'),('familiale','SUITE FAMILIALE'),('superieure','CHAMBRE SUPÉRIEURE')]
    categ_id = fields.Selection(MODE, string="Type de la chambre")
    capacity = fields.Integer(string="capacité", default='2')
    
    chembre_net = fields.Boolean('Chambre nettoyée')
    chembre_net_invisible=fields.Boolean(string="invisible")
    dernier_nettoyage = fields.Datetime('Dernier nettoyage')
    @api.onchange('chembre_net_invisible')
    def _all_checked(self):
        if self.chembre_net_invisible:
            self.dernier_nettoyage = False
        else:           
            self.dernier_nettoyage = True
    

    tarfi_chambre = fields.Float(string="Tarif de la Chambre")
    salle_de_bain = fields.Boolean('Salle de bain')
    toilette = fields.Boolean('Toilette')
    televiseur = fields.Boolean('Téléviseur')
    Douche_privee = fields.Boolean('Douche privée')
    
    telephone = fields.Boolean('Téléphone')
    all_fac_resume=fields.Boolean(string="All")
    num_tel = fields.Integer('Numero de téléphone')

    _rec_name = 'nom'

    @api.onchange('all_fac_resume')
    def _all_checked(self):
        if self.all_fac_resume:
            self.telephone = False
        else:           
            self.telephone = True
    climatiseur = fields.Boolean('Climatiseur')

    description =fields.Char('Description')
    # -*-reservation_id = fields.Many2one(comodel_name='hotel.reservations')

 